export default class CompanyController {}
