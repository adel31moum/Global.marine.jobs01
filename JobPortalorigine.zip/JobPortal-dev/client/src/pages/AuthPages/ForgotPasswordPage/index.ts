export { default } from "./ForgotPasswordPage";
