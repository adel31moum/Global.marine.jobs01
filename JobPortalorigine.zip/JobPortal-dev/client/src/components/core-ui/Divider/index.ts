export { default } from "./Divider";
