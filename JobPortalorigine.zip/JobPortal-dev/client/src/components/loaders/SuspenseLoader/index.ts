export { default } from "./SuspenseLoader";
